<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    Khai bao bien voi php su dung cau truc $
    <!-- De viet code php: Can su dung cap  -->

    <?php
    // Khai bao bien voi php
    // var loichao = "hello" <js>

    $loichao = "Hello World";
    $loiChaoHTML = "<h3>Xin chao, toi duoc echo ra tu the html</h3>"
    ?>
    <h1>Xin chao PHP</h1>
    <?php
    // echo : Chuyen doi 1 bien => text => html
    echo $loiChaoHTML;

    // var_dump($loiChaoHTML);
    ?>
</body>

</html>